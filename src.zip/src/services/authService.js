// src/services/authService.js
// import axios from 'axios';

// const API_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:5000/api';

// const login = async ({ phone, password }) => {
//   const res = await axios.post(`${API_URL}/users/login`, { phone, password });
//   return res.data;
// };

// export default {
//   login,
// };
const authService = {
  login: async ({ phone, name }) => {
    // סימולציה של התחברות: אם יש טלפון ושם — מחזיר משתמש דמה
    if (phone && name) {
      return Promise.resolve({
        id: '123',
        name,
        phone,
        role: phone === '0000' ? 'admin' : 'user',
      });
    } else {
      return Promise.reject(new Error('נא למלא את כל השדות'));
    }
  },
};

export default authService;